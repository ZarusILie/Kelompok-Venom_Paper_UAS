#include <stdio.h>
#include <limits.h>
#include <time.h>
#include <stdlib.h>
#include <sys/times.h>
#include <sys/sysinfo.h>
#include <unistd.h>
#define NANO2SEC 1000000000

 
// A utility function to get sum of array elements
// freq[i] to freq[j]
int sum(int freq[], int i, int j);
struct timespec gettimenow;
double getWtime;
double getCtick;
int ncore;
double cpu_util;

/* A Dynamic Programming based function that calculates
  minimum cost of a Binary Search Tree. */
int optimalSearchTree(char keys[], int freq[], int n)
{
	int i, r, L;
    /* Create an auxiliary 2D matrix to store results
      of subproblems */
    int cost[n][n];
 
    /* cost[i][j] = Optimal cost of binary search tree
       that can be  formed from keys[i] to keys[j].
       cost[0][n-1] will store the resultant cost */
 
    // For a single key, cost is equal to frequency of the key
    for (i = 0; i < n; i++)
        cost[i][i] = freq[i];
 
    // Now we need to consider chains of length 2, 3, ... .
    // L is chain length.
    for (L=2; L<=n; L++)
    {
        // i is row number in cost[][]
        for (i=0; i<=n-L+1; i++)
        {
            // Get column number j from row number i and
            // chain length L
            int j = i+L-1;
            cost[i][j] = INT_MAX;
 
            // Try making all keys in interval keys[i..j] as root
            for (r=i; r<=j; r++)
            {
               // c = cost when keys[r] becomes root of this subtree
               int c = ((r > i)? cost[i][r-1]:0) +
                       ((r < j)? cost[r+1][j]:0) +
                       sum(freq, i, j);
               if (c < cost[i][j])
                  cost[i][j] = c;
            }
        }
    }
    return cost[0][n-1];
}
 
// A utility function to get sum of array elements
// freq[i] to freq[j]
int sum(int freq[], int i, int j)
{
	int k;
    int s = 0;
    for (k = i; k <=j; k++)
       s += freq[k];
    return s;
}

double get_wall_time () {
    if (clock_gettime(CLOCK_REALTIME,&gettimenow)){
        //error handle
        return 0;
    }
    return ( (double)gettimenow.tv_sec + ( (double)gettimenow.tv_nsec / NANO2SEC ) );
}


double get_cpu_time () {
    return ( (double)clock() / sysconf (_SC_CLK_TCK));
}

int core_logical () {
    return (sysconf(_SC_NPROCESSORS_ONLN));
}


// Driver program to test above functions
int main(int argc,char *argv)
{	
    char keys[] = {'A','B','C','D','E'};
    int freq[] = {13, 15, 17, 18, 19};
    int n = sizeof(keys)/sizeof(keys[0]);
    printf("Cost of Optimal BST is %d ",
                 optimalSearchTree(keys, freq, n));
                 
	getWtime = get_wall_time ();
    printf("\nWall time : %f \n", getWtime);

    getCtick = get_cpu_time ();
    printf("\nCPU time : %f \n", getCtick);

    ncore = core_logical ();
    printf("\nNo of cores : %d \n", ncore);

    cpu_util = (getCtick/ncore/getWtime);
    printf("\nCPU Utilization : %f %% \n", cpu_util);
    
    struct sysinfo s_info;

char info_buff[100];

while(1)

{

if(sysinfo(&s_info)==0)

{

sprintf(info_buff,"Total memory: %.ld M",s_info.totalram/1024/1024);

printf("%s\n",info_buff);

sprintf(info_buff,"Unused memory: %.ld M",s_info.freeram/1024/1024);

printf("%s\n",info_buff);

sprintf(info_buff,"Total swap area memory: %.ld M",s_info.totalswap/1024/1024);

printf("%s\n",info_buff);

sprintf(info_buff,"Unused memory in swap area: %.ld M",s_info.freeswap/1024/1024);

printf("%s\n",info_buff);

sprintf(info_buff,"System running time: %.ld minutes",s_info.uptime/60);

printf("%s\n",info_buff);

printf("\n\n");

}

sleep(100);

}
    return 0;
}

/* Referensi 
https://www.geeksforgeeks.org/optimal-binary-search-tree-dp-24/ */

